/*!\file window.c
 *
 * \brief utilisation de GL4Dummies et Lib Assimp pour chargement de
 * modèles 3D sous différents formats.
 *
 * \author Farès Belhadj amsi@up8.edu
 * \date May 21 2023
 * Yanis Makhloufi 21003808 L2Y
 */

#include <GL4D/gl4duw_SDL2.h>
#include <SDL_image.h>
#include "assimp.h"
#include <stdio.h>
#include <assert.h>
#include <GL4D/gl4dm.h>
#include <GL4D/gl4dg.h>
#include <GL4D/gl4du.h>
#include <GL4D/gl4dp.h>
#include <SDL_ttf.h>

/*!\brief opened window width */
static int _windowWidth = 600;
/*!\brief opened window height */
static int _windowHeight = 800;
/*!\brief GLSL program Id */
static GLuint _pId = 0;
GLuint _texId[1] = { 0 };
GLuint quad = 0;

/*!\brief identifiant de modèles générés à partir de fichiers 3D (3dsmax, obj, ...) */
static GLuint _id_modele[9] = { 0 };
static void init(void);
static void sortie(void);
static void resize(int w, int h);
static void draw(void);


int main(int argc, char ** argv) {
  if(!gl4duwCreateWindow(argc, argv, "Yaniss", GL4DW_POS_UNDEFINED, GL4DW_POS_UNDEFINED,
                         _windowWidth, _windowHeight, GL4DW_RESIZABLE | GL4DW_SHOWN))
    return 1;
  init();
  atexit(sortie);
  gl4duwResizeFunc(resize);
  gl4duwDisplayFunc(draw);
  gl4duwMainLoop();

  return 0;
}

void init(void) {
  // Charger deux fois le modèle du ballon de soccer
  _id_modele[0] = assimpGenScene("models/sun/13913_Sun_v2_l3.obj"); // Soleil
  _id_modele[1] = assimpGenScene("models/venus/13901_Venus_v1_l3.obj"); // Venus
  _id_modele[2] = assimpGenScene("models/earth/earth.obj"); // Terre
  _id_modele[3] = assimpGenScene("models/moon/Moon.obj"); // Lune
  _id_modele[4] = assimpGenScene("models/mars/13903_Mars_v1_l3.obj"); // Mars
  _id_modele[5] = assimpGenScene("models/jupiter/13905_Jupiter_V1_l3.obj"); // Jupiter
  _id_modele[6] = assimpGenScene("models/saturne/13906_Saturn_v1_l3.obj"); // SAturne
  _id_modele[7] = assimpGenScene("models/uranus/13907_Uranus_v2_l3.obj"); // Uranus
  _id_modele[8] = assimpGenScene("models/neptune/13908_Neptune_V2_l3.obj"); // SAturne


  quad = gl4dgGenQuadf();
  

  glEnable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);

  _pId = gl4duCreateProgram("<vs>shaders/basic.vs", "<fs>shaders/basic.fs", NULL);
  gl4duGenMatrix(GL_FLOAT, "modelViewMatrix");
  gl4duGenMatrix(GL_FLOAT, "projectionMatrix");
  glEnable(GL_CULL_FACE);
  glCullFace(GL_BACK);
  resize(_windowWidth, _windowHeight);
 // initText(&_texId[0], "Credit :\n\nGL4D : Fares Belhadj\n Los Planetos : Yanis Makhloufi\nMusic : y'en a pas lol\nPolice : basique\n");
}


/*!\brief function called by GL4Dummies' loop at resize. Sets the
 *  projection matrix and the viewport according to the given width
 *  and height.
 * \param w window width
 * \param h window height
 */
void resize(int w, int h) {
  _windowWidth = w; 
  _windowHeight = h;
  glViewport(0, 0, _windowWidth, _windowHeight);
  gl4duBindMatrix("projectionMatrix");
  gl4duLoadIdentityf();
  gl4duFrustumf(-0.005, 0.005, -0.005 * _windowHeight / _windowWidth, 0.005 * _windowHeight / _windowWidth, 0.01, 1000.0);
  /* alternative : gl4duPerspectivef(60.0, (GLfloat)_windowWidth/(GLfloat)_windowHeight, 0.01, 1000.0); */
  gl4duBindMatrix("modelViewMatrix");
}

void draw(void) {
  static GLfloat angle = 0.0f;  // Angle pour la rotation du petit ballon autour du gros
  static GLfloat selfRotation = 0.0f;  // Angle pour la rotation du gros ballon autour de lui-même
  static GLfloat smallSelfRotation = 0.0f;  // Angle pour la rotation du petit ballon autour de lui-même
  static GLfloat angel = 0.0f;
  static GLfloat jupiterRotation = 0.0;
  static GLfloat jupitertourne = 0.0;
  static GLfloat saturnerotation = 0.0; 
  static GLfloat saturnetourne = 0.0;
  static GLfloat neptune = 0.0;
  static GLfloat zoomLevel = 30.0f; // Niveau de zoom initial
  static const GLfloat minZoom = 15.0f; // Zoom minimum
  static const GLfloat maxZoom = 60.0f; // Zoom maximum
  static int zoomIn = 1; // 1 pour zoom in, 0 pour zoom out

  static int initTime = -1;  // Initialisation du temps de démarrage
  static int viewChanged = 0;
  static int viewStage = 0;
  
  static double lastTime = 0.0;
  
  double currentTime = SDL_GetTicks();
  if (lastTime == 0) lastTime = currentTime;
  double dt = (currentTime - lastTime) / 1000.0;
  lastTime = currentTime;

  GLfloat lum[4] = {0.0, 0.0, 5.0, 1.0};

      // Mise à jour du zoom
  if (zoomIn) {
      zoomLevel -= dt * 5.0f; // Vitesse de zoom
      if (zoomLevel <= minZoom) {
          zoomLevel = minZoom;
          zoomIn = 0; // Commencer à dézoomer
        }
  } else {
      zoomLevel += dt * 5.0f; // Vitesse de dézoom
      if (zoomLevel >= maxZoom) {
          zoomLevel = maxZoom;
          zoomIn = 1; // Recommencer à zoomer
        }
    }

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram(_pId);
    glUniform4fv(glGetUniformLocation(_pId, "lumpos"), 1, lum);

    // Gestion des changements de vue
    switch (viewStage) {
        case 0:
            gl4duBindMatrix("modelViewMatrix");
            gl4duLoadIdentityf();
            gl4duLookAtf(0.0f, 0.0f, zoomLevel, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
            if (currentTime - initTime >= 10000) {
                viewStage = 1;
            }
            break;
        case 1:
            gl4duBindMatrix("modelViewMatrix");
            gl4duLoadIdentityf();
            gl4duLookAtf(0.0f, zoomLevel, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f);
            if (currentTime - initTime >= 20000) {
                viewStage = 2;
            }
            break;
        case 2:
            gl4duBindMatrix("modelViewMatrix");
            gl4duLoadIdentityf();
            gl4duLookAtf(0.0f, 0.0f, 50.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);
            break;
    }
  // Soleil
    glBindTexture(GL_TEXTURE_2D, _texId[0]);
    gl4duPushMatrix();
    gl4duScalef(4.0f, 4.0f, 4.0f);  // Mise à l'échelle pour rendre le ballon plus gros
    gl4duRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  // Redressement de la Terre pour que le pôle Nord soit en haut
    gl4duRotatef(selfRotation, 0.0f, 0.0f, 0.0f);  // Rotation autour de son propre axe Z
    assimpDrawScene(_id_modele[0]);
    gl4duPopMatrix();

  // Venus
    gl4duPushMatrix();
    gl4duRotatef(-angle, 0.0f, 1.0f, 0.0f);  // Rotation rapide autour du gros ballon
    gl4duTranslatef(2.5f, 0.0f, 0.0f);  // Déplacement du petit ballon loin du centre
    gl4duScalef(0.5f, 0.5f, 0.5f);  // Mise à l'échelle pour rendre le ballon plus petit
    gl4duRotatef(smallSelfRotation, 0.0f, 1.0f, 0.0f);  // Rotation autour de son propre axe
    assimpDrawScene(_id_modele[1]);
    gl4duPopMatrix();

  // Terre
    gl4duPushMatrix();
    gl4duRotatef(angle, 0.0f, 1.0f, 0.0f);
    gl4duTranslatef(4.0f, 0.0f, 0.0f);  // Déplacement loin du centre
    gl4duScalef(1.0f, 1.0f, 1.0f);  // Mise à l'échelle pour rendre le ballon plus gros
    gl4duRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  
    gl4duRotatef(selfRotation, 0.0f, 0.0f, 1.0f);  // Rotation autour de son propre axe Z
    assimpDrawScene(_id_modele[2]);
    gl4duPopMatrix();

  //Lune 
  gl4duPushMatrix();
  gl4duRotatef(angle, 0.0f, 1.0f, 0.0f); // Utilisez le même angle que pour la Terre si vous voulez une rotation synchrone
  gl4duTranslatef(4.0f, 0.0f, 0.0f);  // Commencez par la position de la Terre
  gl4duTranslatef(0.8f, 0.0f, 0.0f);  // Écart par rapport à la Terre
  gl4duScalef(0.3f, 0.3f, 0.3f);  // Taille de la petite boule
  gl4duRotatef(selfRotation, 0.0f, 0.0f, 1.0f);  // Rotation propre de la petite boule si nécessaire
  assimpDrawScene(_id_modele[3]);
  gl4duPopMatrix();

  
  
  
    // Mars
    gl4duPushMatrix();
    gl4duRotatef(angel, 0.0f, 1.0f, 0.0f); // determine la vitesse de rota autour du soleil 
    gl4duTranslatef(6.0f, 0.0f, 0.0f);  // Déplacement loin du centre
    gl4duScalef(0.8f, 0.8f, 0.8f);  // taille 
    gl4duRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  
    gl4duRotatef(selfRotation, 0.0f, 0.0f, 1.0f);  // Rotation autour de son propre axe Z
    assimpDrawScene(_id_modele[4]);
    gl4duPopMatrix();
  
  // Jupiter 
    gl4duPushMatrix();
    gl4duRotatef(jupitertourne, 0.0f, 1.0f, 0.0f);
    gl4duTranslatef(9.0f, 0.0f, 0.0f);  // Déplacement loin du centre
    gl4duScalef(3.0f, 3.0f, 3.0f);  // Mise à l'échelle pour rendre le ballon plus gros
    gl4duRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  
    gl4duRotatef(jupiterRotation, 0.0f, 0.0f, 1.0f);  // Rotation autour de son propre axe Z
    assimpDrawScene(_id_modele[5]);
    gl4duPopMatrix();
  
  //Saturn 
    gl4duPushMatrix();
    gl4duRotatef(saturnetourne, 0.0f, 1.0f, 0.0f);
    gl4duTranslatef(12.0f, 0.0f, 0.0f);  // Déplacement loin du centre
    gl4duScalef(2.5f, 2.5f, 2.5f);  // Mise à l'échelle pour rendre le ballon plus gros
    gl4duRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  
    gl4duRotatef(saturnerotation, 0.0f, 0.0f, 1.0f);  // Rotation autour de son propre axe Z
    assimpDrawScene(_id_modele[6]);
    gl4duPopMatrix();
  
  
    //Uranus
    gl4duPushMatrix();
    gl4duRotatef(angle, 0.0f, 1.0f, 0.0f);
    gl4duTranslatef(15.0f, 0.0f, 0.0f);  // Déplacement loin du centre
    gl4duScalef(2.0f, 2.0f, 2.0f);  // Mise à l'échelle pour rendre le ballon plus gros
    gl4duRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  
    gl4duRotatef(saturnerotation, 0.0f, 0.0f, 1.0f);  // Rotation autour de son propre axe Z
    assimpDrawScene(_id_modele[7]);
    gl4duPopMatrix();
  
  
  
    //Neptune
    gl4duPushMatrix();
    gl4duRotatef(neptune, 0.0f, 1.0f, 0.0f);
    gl4duTranslatef(18.0f, 0.0f, 0.0f);  // Déplacement loin du centre
    gl4duScalef(2.0f, 2.0f, 2.0f);  // Mise à l'échelle pour rendre le ballon plus gros
    gl4duRotatef(-90.0f, 1.0f, 0.0f, 0.0f);  
    gl4duRotatef(selfRotation, 0.0f, 0.0f, 1.0f);  // Rotation autour de son propre axe Z
    assimpDrawScene(_id_modele[8]);
    gl4duPopMatrix();
  
  
  
  
  
  
  
  
  //quad "credit"
  gl4duPushMatrix();
  gl4duRotatef(angle, 0.0f, 1.0f, 0.0f);  // Rotation rapide autour du gros ballon
  gl4duTranslatef(3.0f, 0.0f, 0.0f);  // Déplacement du petit ballon loin du centre
  gl4duScalef(0.5f, 0.5f, 0.5f);
  gl4dgDraw(quad); // Mise à l'échelle pour rendre le ballon plus petit
  gl4duPopMatrix();

/*  gl4duPushMatrix();
    gl4duRotatef(angle, 0.0f, 1.0f, 0.0f);  // Rotation rapide autour du gros ballon
    gl4duTranslatef(2.0f, 0.0f, 0.0f);  // ecart entre le ballon et le centre la terre
    gl4duScalef(0.5f, 0.5f, 0.5f);  // Mise à l'échelle pour rendre le ballon plus petit
    gl4duRotatef(smallSelfRotation, 0.0f, 1.0f, 0.0f);  // Rotation autour de son propre axe
    assimpDrawScene(_id_modele[0]);
    gl4duPopMatrix(); */

  // Mise à jour des angles pour la rotation
  angle += 60.0 * dt;  // Vitesse de rotation autour du gros ballon
  selfRotation += 45.0 * dt;  // Vitesse de rotation du gros ballon sur lui-même
  smallSelfRotation += 10.0 * dt;  // Vitesse de rotation du petit ballon sur lui-même
  angel += 120.0 * dt; // test
  jupiterRotation += 120 * dt;
  jupitertourne += 100 * dt;
  saturnerotation += 90 * dt;
  saturnetourne += 70 * dt;
  neptune += 60*dt; 
  lastTime = currentTime;
  glUseProgram(0);


}
void sortie(void) {
    if(_texId[0]) {
    /* on supprime la texture côté OpenGL */
    glDeleteTextures(2, _texId);
    _texId[0] = 0;
  }
  gl4duClean(GL4DU_ALL);
}