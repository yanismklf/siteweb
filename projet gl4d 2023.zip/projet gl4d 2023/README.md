Auteur : Farès Belhadj
email : amsi@up8.edu
date mai 2023

Description :

Exemple de loader de modèles 3D gérant plusieurs formats de fichier (voir https://github.com/assimp/assimp/blob/master/doc/Fileformats.md)

Dépendance :

GL4Dummies (donc SDL2) : https://github.com/noalien/GL4Dummies
libAssimp : https://github.com/assimp/assimp



