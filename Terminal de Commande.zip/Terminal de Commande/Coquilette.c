#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <limits.h>
#include <ctype.h>

#define NB_BUILTINS 3

struct command {
    int argc;
    char **argv;
    char *input_file;
    char *output_file;
    char *error_file;
    int append; 
};

struct builtin {
    char *name;
    int (*func)(int argc, char **argv);
};

int builtin_exit(int argc, char **argv) {
    exit(EXIT_SUCCESS);
}

int builtin_cd(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "cd: argument manquant\n");
        return 1;
    }
    if (chdir(argv[1]) != 0) {
        perror("cd");
        return 1;
    }
    return 0;
}

int builtin_export(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: export VAR=value\n");
        return 1;
    }
    char* var = strtok(argv[1], "=");
    char* value = strtok(NULL, "");
    if (var == NULL || value == NULL) {
        fprintf(stderr, "export: Mauvais format. Utilisez VAR=value.\n");
        return 1;
    }
    if (setenv(var, value, 1) != 0) {
        perror("export");
        return 1;
    }
    return 0;
}

struct builtin builtins[NB_BUILTINS] = {
    {"exit", builtin_exit},
    {"cd", builtin_cd},
    {"export", builtin_export}
};

int find_builtins(const char *cmd) {
    for (int i = 0; i < NB_BUILTINS; i++) {
        if (strcmp(cmd, builtins[i].name) == 0) return i;
    }
    return -1;
}

int count_args(const char *s) {
    int n = 0;
    char p = ' ';
    while (*s) {
        if (isspace(p) && !isspace(*s)) n++;
        p = *s++;
    }
    return n;
}

void escape(char *input) {
    int i = 0;
    while (input[i] != '\0') {
        if (input[i] == '\\' && input[i+1] == 't') {
            input[i] = '\t';
            memmove(&input[i+1], &input[i+2], strlen(input) - i - 1);
        } else if (input[i] == '\\' && input[i+1] == 'n') {
            input[i] = '\n';
            memmove(&input[i+1], &input[i+2], strlen(input) - i - 1);
        }
        i++;
    }
}

struct command *parse_cmd(const char *buf) {
    struct command *cmd = malloc(sizeof(*cmd));
    memset(cmd, 0, sizeof(struct command)); 
    cmd->argc = 0;
    cmd->argv = malloc((count_args(buf) + 1) * sizeof(char*)); 
    char *tokens = strdup(buf);
    char *next_token = tokens;
    char *token = strtok_r(tokens, " ", &next_token);

    while (token != NULL) {
        if (strcmp(token, "<") == 0) {
            token = strtok_r(NULL, " ", &next_token);
            cmd->input_file = strdup(token);
        } else if (strcmp(token, ">") == 0) {
            token = strtok_r(NULL, " ", &next_token);
            cmd->output_file = strdup(token);
            cmd->append = 0;
        } else if (strcmp(token, ">>") == 0) {
            token = strtok_r(NULL, " ", &next_token);
            cmd->output_file = strdup(token);
            cmd->append = 1;
        } else {
            cmd->argv[cmd->argc++] = strdup(token);
        }
        token = strtok_r(NULL, " ", &next_token);
    }
    cmd->argv[cmd->argc] = NULL;
    free(tokens); 
    return cmd;
}

void applique_redirections(struct command *cmd) {
    if (cmd->input_file) {
        int fd_in = open(cmd->input_file, O_RDONLY);
        if (fd_in < 0) { perror("open input file"); exit(EXIT_FAILURE); }
        dup2(fd_in, STDIN_FILENO);
        close(fd_in);
    }

    if (cmd->output_file) {
        int flags = O_WRONLY | O_CREAT | (cmd->append ? O_APPEND : O_TRUNC);
        int fd_out = open(cmd->output_file, flags, 0666);
        if (fd_out < 0) { perror("open output file"); exit(EXIT_FAILURE); }
        dup2(fd_out, STDOUT_FILENO);
        close(fd_out);
    }

    if (cmd->error_file) {
        int flags = O_WRONLY | O_CREAT | (cmd->append ? O_APPEND : O_TRUNC);
        int fd_err = open(cmd->error_file, flags, 0666);
        if (fd_err < 0) { perror("open error file"); exit(EXIT_FAILURE); }
        dup2(fd_err, STDERR_FILENO);
        close(fd_err);
    }
}


void expansion_variable_environement(char **argv) {
    for (int i = 0; argv[i] != NULL; i++) {
        if (argv[i][0] == '$') { 
            char *varName = argv[i] + 1;
            char *value = getenv(varName);
            if (value) {
                argv[i] = strdup(value); 
            }
        }
    }
}


void free_cmd(struct command *cmd) {
    if (cmd) {
        for (int i = 0; i < cmd->argc; i++) {
            free(cmd->argv[i]);
        }
        free(cmd->argv);
        free(cmd->input_file);
        free(cmd->output_file);
        free(cmd->error_file);
        free(cmd);
    }
}

int exec_cmd(struct command *cmd) {
    pid_t pid;
    int status;

    pid = fork();
    if (pid == -1) {
        perror("fork");
        return -1;
    } else if (pid == 0) {
        applique_redirections(cmd);
        expansion_variable_environement(cmd->argv); 
        execvp(cmd->argv[0], cmd->argv);
        perror("execvp");
        exit(EXIT_FAILURE);
    } else {
        waitpid(pid, &status, 0);
        if (WIFEXITED(status)) {
            return WEXITSTATUS(status);
        } else {
            return -1;
        }
    }
}

void execute_command(struct command *cmd) {
    if (cmd->argv[0] == NULL) { 
        return;
    }
    int cmdIndex = find_builtins(cmd->argv[0]);
    if (cmdIndex != -1) {
        builtins[cmdIndex].func(cmd->argc, cmd->argv);
    } else {
        int status = exec_cmd(cmd);
        printf("Command éxécuté avec : %d\n", status);
    }
}

int main(void) {
    char *username, hostname[256], workingdir[PATH_MAX];
    char buff[2048];

    signal(SIGINT, SIG_IGN);

    if ((username = getlogin()) == NULL) {
        perror("erreur getlogin");
        exit(EXIT_FAILURE);
    }

    if (gethostname(hostname, sizeof(hostname)) < 0) {
        perror("erreur gethostname");
        exit(EXIT_FAILURE);
    }

    while (1) {
        if (getcwd(workingdir, sizeof(workingdir)) == NULL) {
            perror("erreur getcwd");
            continue;
        }
        fprintf(stderr, "%s@%s:%s$ ", username, hostname, workingdir);
        fflush(stderr);
        if (!fgets(buff, sizeof(buff), stdin)) {
            if (feof(stdin)) break;
            perror("erreur");
            continue;
        }
        buff[strcspn(buff, "\n")] = 0; 
        escape(buff); 

        struct command *cmd = parse_cmd(buff);
        if (!cmd) continue; 

        execute_command(cmd);

        free_cmd(cmd);
    }

    fprintf(stderr, "\nBye!\n");
    return 0;
}
