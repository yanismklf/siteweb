#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

#define MAX_NODES 100 
// edge = arete 
// structure du noeud
typedef struct {
    int weight; //poids noeud
    int* edgeWeights; //poids des aretes sortantes
    char name[50]; 
} Node;

// Structure de l'arete
typedef struct {
    int start; 
    int end;
    int weight;
} Edge;

// Déclaration des fonctions avant le main pour qu'il puisse fonctionne comme il faut
void readfile(char *filename, Node graph[], int *numNodes, Edge edges[], int *numEdges, int *src, int *dest);
void dijkstra(Node graph[], int numNodes, Edge edges[], int numEdges, int src, int dest);
int minDistance(int dist[], int sptSet[], int numNodes);
void printPath(Node graph[], int parent[], int j);
void printSolution(int dist[], Node graph[], int parent[], int src, int dest);
// On mets dans chaque fonction ce qu'on va utiliser comme parametres dedans 



int main() {
Node graph[MAX_NODES];
Edge edges[MAX_NODES * MAX_NODES];

// noeuds et aretes 
int numNodes, numEdges;
// la source et la destination
int src, dest;
// chargement du fichier texte 
char filename[] = "graph.txt";
// appel de la fonction qui vas lirer le fichier texte 
readfile(filename, graph, &numNodes, edges, &numEdges, &src, &dest);
// dijksra sert a trouver le chemin le plus court
dijkstra(graph, numNodes, edges, numEdges, src, dest);

return 0;
}


void readfile(char *filename, Node graph[], int *numNodes, Edge edges[], int *numEdges, int *src, int *dest) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Erreur lorsqu'on a essayé d'ouvrir le fichier");
        exit(EXIT_FAILURE); // Ouverture du fichier si celui si est vide = error 
    }
    // Lecture du nombre de nœuds
    fscanf(file, "%d", numNodes);
    printf("Nombre de nœuds : %d\n", *numNodes); // on affiche le nombre de noeuds de notre fichier

    // Lecture des informations sur les nœuds
    for (int i = 0; i < *numNodes; i++) { // la boucle parcours le fichier
        fscanf(file, "%s %d", graph[i].name, &graph[i].weight); // on enregistre les info trouvé
// dans le fichier au nom de graphs name et graphs weight tel que 'Paris 15'

        // Allocation et initialisation 
        graph[i].edgeWeights = (int*)malloc(*numNodes * sizeof(int)); // on donne de la memoire equivalent a sizeof x nombre de noeuds
        for (int j = 0; j < *numNodes; j++) { // se balade dans le graphe pour tout mettre a la valeur int max
            graph[i].edgeWeights[j] = INT_MAX; // int max = infinie 
        }
    }

    // Lecture du nombre d'arêtes
    fscanf(file, "%d", numEdges); // lecture du fichier, valeur stocker dans numedges (arete dans graphe) 
    fgetc(file);  // Pour consommer le caractère de fin de ligne après le nombre d'arêtes

    printf("Nombre d'arêtes : %d\n", *numEdges); // on demande donc d'afficher le nombre d'aretes totale

    // Lecture des informations sur les arêtes
    for (int i = 0; i < *numEdges; i++) { // parcours chaque arete du graphe pour le nombre vue au dessus 
        char startName[50], endName[50];
        fscanf(file, "%s %s %d", startName, endName, &edges[i].weight); // recherche des infos dans le fichier

        // Recherche des indices des nœuds à partir des noms
        edges[i].start = -1;
        edges[i].end = -1;
        for (int j = 0; j < *numNodes; j++) {
            if (strcmp(graph[j].name, startName) == 0) {
                edges[i].start = j;
            }
            if (strcmp(graph[j].name, endName) == 0) {
                edges[i].end = j;
            } // compare les noms lu dans le fichier avec ceux du noeuds dans le graph
        }

    }

    // Lecture du nœud source et du nœud destination
    char srcName[50], destName[50];
    fscanf(file, "%s %s", srcName, destName); //lecture a partir du fichier du noeuds source et destination

    // Recherche des indices des nœuds source et destination à partir des noms
    *src = -1;
    *dest = -1;
    for (int i = 0; i < *numNodes; i++) { // parcours du graph 
        if (strcmp(graph[i].name, srcName) == 0) {
            *src = i;
        }
        if (strcmp(graph[i].name, destName) == 0) {
            *dest = i;
        }// cherche des informations et les compares avec ceux qui a été vu dans le fichier d'avant
        // stocker dans le *dest et *src
    }

    if (*src == -1 || *dest == -1) { // regarde si les informations ont été trouvé 
        fprintf(stderr, "Erreur : Nœud source ou destination introuvable.\n"); //si les informations n'ont pas été trouvé un message d'erreur est envoyer
        exit(EXIT_FAILURE);
    }



    printf("Noeud source : %s\n", graph[*src].name); // depart 
    printf("Noeud destination : %s\n", graph[*dest].name); // arrivé 

}

void dijkstra(Node graph[], int numNodes, Edge edges[], int numEdges, int src, int dest) {
    int dist[numNodes];    // tab contenant les distances les plus courtes 
    int sptSet[MAX_NODES];  // tab qui suit les noeuds deja visités 
    int parent[MAX_NODES];  // tab qui stock le chemin le plus court


    for (int i = 0; i < numNodes; i++) { // boucle parcours noeud dans le graphe 
        dist[i] = INT_MAX; // distance initiale infinie 
        sptSet[i] = 0; // noeud deja vu est de 0
        parent[i] = -1; // car au depart il est inconnue
    }
    //permet a l'algoritme de commencer a faire le chemin le plus court a partir du noeud source 
    // la boucle s'execute jusqu'a tt soit passé 

    // La distance du nœud source à lui-même est toujours 0
    dist[src] = 0;

    // Algorithme de Dijkstra
    for (int count = 0; count < numNodes - 1; count++) { // nombre - 1
        int u = minDistance(dist, sptSet, numNodes); 
        sptSet[u] = 1; // u inclus dans le chemin le plus court 

        // Parcourir les arêtes sortantes du nœud u
        for (int v = 0; v < numEdges; v++) { // parcours tt les aretes du graphes
            if (!sptSet[edges[v].end] && graph[u].weight + edges[v].weight < dist[edges[v].end]) { // verifier si le noeud destination de l'arete n'a pas encore été inclus dans le chemin le plus court
                parent[edges[v].end] = u;  // si la condition est vrai alors les tab parent et dist sont mit a jour 
                dist[edges[v].end] = graph[u].weight + edges[v].weight; // distance minimale jusqu'au noeud de destination est mise a jour 
            }
        }


    }

    // Affichage de la solution
    printSolution(dist, graph, parent, src, dest);
}

int minDistance(int dist[], int sptSet[], int numNodes) {
    int min = INT_MAX, min_index; // mit a la valeur max pour assuré qu'une distance sera toujours plus petite 
    for (int v = 0; v < numNodes; v++) { // parcour tous les noeuds du graphe 
        if (sptSet[v] == 0 && dist[v] < min) { // si le noeud v na pas encore été inclus dans le chemin le plus court, et si la distance du v est plus petite que celle enregistré 
            min = dist[v]; // msj de la distance actuelle jusqu'au noeud v 
            min_index = v; // msj de l'indice avec la distance min
        }
    }
    return min_index; // distance min non inclus dans le chemin le plus court 
}

void printPath(Node graph[], int parent[], int j) {
    if (parent[j] == -1)
        return; // la fonctionne se termine si il a pas de parent 

    printPath(graph, parent, parent[j]); 

    printf(" > %s", graph[j].name);
}

void printSolution(int dist[], Node graph[], int parent[], int src, int dest) {
printf("Le plus court chemin entre %s et %s est : %d\n", graph[src].name, graph[dest].name, dist[dest]);
printf("Chemin : %s", graph[src].name);
printPath(graph, parent, dest);
printf("\n");
    
}