

1) gcc projet.c -o Projet
2) ./Projet
3) Yanis Makhloufi l2b 21003808
4) Il y'a une fonction readfile qui vas permettre de traite entierement le ficher, et une fonction djikstra qui permet le calcul du chemin le plus court. 