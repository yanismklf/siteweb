#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <cmath>

//couelur 
#define RED "\033[31m"
#define CYAN "\033[36m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define RESET "\033[0m"

class Animal {
public:
    Animal(int x, int y, int age_max) : x(x), y(y), age_max(age_max), age(0), faim(0) {} 
    virtual void se_deplacer(int max_x, int max_y, std::vector<std::vector<char>>& grille) = 0; 
    virtual void manger(std::vector<std::vector<char>>& grille, std::vector<Animal*>& moutons, std::vector<Animal*>& loups) = 0;
    virtual bool est_vivant() = 0;
    void vieillir() { age++; faim++; }
    int get_x() const { return x; }
    int get_y() const { return y; } 
    virtual char get_type() const = 0;
 
protected:
    int x, y; 
    int age_max, age;
    int faim;
}; 

class Mouton : public Animal {
public:
    Mouton(int x, int y) : Animal(x, y, 50), mange_par_loup(false) {} 
    void se_deplacer(int max_x, int max_y, std::vector<std::vector<char>>& grille) override; 
    void manger(std::vector<std::vector<char>>& grille, std::vector<Animal*>& moutons, std::vector<Animal*>& loups) override; 
    bool est_vivant() override;
    char get_type() const override { return 'M'; }
    bool mange_par_loup; 
 
private:
    std::pair<int, int> trouver_herbe_proche(std::vector<std::vector<char>>& grille, int max_x, int max_y); 
};

class Loup : public Animal {
public: 
    Loup(int x, int y) : Animal(x, y, 60) {}  
    void se_deplacer(int max_x, int max_y, std::vector<std::vector<char>>& grille) override; 
    void manger(std::vector<std::vector<char>>& grille, std::vector<Animal*>& moutons, std::vector<Animal*>& loups) override; 
    bool est_vivant() override; 
    char get_type() const override { return 'L'; } 
}; 

class Univers {
public:
    Univers(int m, int n, int nb_moutons, int nb_loups);
    ~Univers();
    void initialiser();
    void afficher();
    void tour_suivant();
    bool est_mort();
    void faire_pousser_herbe();

private:
    int m, n;
    int tour;
    static const int LIMITE_MOUTONS = 100;
    static const int LIMITE_LOUPS = 100;
    std::vector<std::vector<char>> grille; 
    std::vector<Animal*> moutons;
    std::vector<Animal*> loups;
    void deplacer_animaux();
    void gerer_reproduction(); 
    void gerer_alimentation();
    void mettre_a_jour_herbe();
    void nettoyer_animaux_morts();
    bool case_valide(int x, int y); 
};

Univers::Univers(int m, int n, int nb_moutons, int nb_loups) : m(m), n(n), grille(m, std::vector<char>(n, ' ')), tour(0) { 
    for (int i = 0; i < nb_moutons; ++i) {
        int x = rand() % m;
        int y = rand() % n;
        moutons.push_back(new Mouton(x, y));
    }

    for (int i = 0; i < nb_loups; ++i) {
        int x = rand() % m; 
        int y = rand() % n;
        loups.push_back(new Loup(x, y)); 
    }  
}

Univers::~Univers() { 
    for (auto mouton : moutons) {
        delete mouton;
    } 
    for (auto loup : loups) {
        delete loup; 
    }
}

bool Univers::case_valide(int x, int y) {
    return x >= 0 && x < m && y >= 0 && y < n;
}

void Univers::gerer_reproduction() { 
    std::vector<Animal*> nouveaux_moutons;
    std::vector<Animal*> nouveaux_loups; 

    for (auto& mouton : moutons) {
        if (rand() % 100 < 20) { // 5% de chance de reproduction par tour
            int new_x = rand() % m; 
            int new_y = rand() % n;
            if (moutons.size() + nouveaux_moutons.size() < LIMITE_MOUTONS) { 
                nouveaux_moutons.push_back(new Mouton(new_x, new_y));
                std::cout << "Un nouveau mouton est né à la position : (" << new_x << ", " << new_y << ")" << std::endl; 
            }
        }
    }

    for (auto& loup : loups) {
        if (rand() % 100 < 7) { // 5% de chance de reproduction par tour
            int new_x = rand() % m; 
            int new_y = rand() % n;
            if (loups.size() + nouveaux_loups.size() < LIMITE_LOUPS) { 
                nouveaux_loups.push_back(new Loup(new_x, new_y));
                std::cout << "Un nouveau loup est né à la position : (" << new_x << ", " << new_y << ")" << std::endl; 
            }
        }
    }

    moutons.insert(moutons.end(), nouveaux_moutons.begin(), nouveaux_moutons.end()); 
    loups.insert(loups.end(), nouveaux_loups.begin(), nouveaux_loups.end()); 
}

void Univers::mettre_a_jour_herbe() {
    for (int i = 0; i < m; ++i) { 
        for (int j = 0; j < n; ++j) {
            if (grille[i][j] == ' ' && (rand() % 100) < 5) { // 2% de chance de repousse 
                grille[i][j] = 'H';
                std::cout << "De l'herbe a repoussé à la position : (" << i << ", " << j << ")" << std::endl; 
            }
        }
    }
}

void Univers::deplacer_animaux() { 
    for (auto& mouton : moutons) {
        mouton->se_deplacer(m, n, grille);
    }
    for (auto& loup : loups) {
        loup->se_deplacer(m, n, grille);
    } 
}

void Univers::gerer_alimentation() { 
    for (auto& mouton : moutons) {
        mouton->manger(grille, moutons, loups); 
    }
    for (auto& loup : loups) { 
        loup->manger(grille, moutons, loups); 
    }
}

void Univers::nettoyer_animaux_morts() {
    for (auto it = moutons.begin(); it != moutons.end();) {
        if (!(*it)->est_vivant()) {
            grille[(*it)->get_x()][(*it)->get_y()] = 'S'; // Déposer des sels minéraux où le mouton est mort 
            Mouton* mouton = dynamic_cast<Mouton*>(*it); 
            std::string cause_mort = mouton && mouton->mange_par_loup ? "mangé par un loup" : "mort naturellement";
            std::cout << "Un mouton est mort (" << cause_mort << ") à la position : (" << (*it)->get_x() << ", " << (*it)->get_y() << ")" << std::endl;
            delete *it; 
            it = moutons.erase(it); 
        } else {
            ++it;
        }
    }

    for (auto it = loups.begin(); it != loups.end();) { 
        if (!(*it)->est_vivant()) { 
            grille[(*it)->get_x()][(*it)->get_y()] = 'S'; // Déposer des sels minéraux où le loup est mort
            std::cout << "Un loup est mort à la position : (" << (*it)->get_x() << ", " << (*it)->get_y() << ")" << std::endl; 
            delete *it;
            it = loups.erase(it);
        } else {
            ++it;
        }
    }
}

void Univers::initialiser() {
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            if (rand() % 100 < 10) { // 10% de chance d'avoir de l'herbe initialement
                grille[i][j] = 'H';
                std::cout << "De l'herbe est présente initialement à la position : (" << i << ", " << j << ")" << std::endl;
            } else {  
                grille[i][j] = ' ';
            } 
        }
    }
}

void Univers::faire_pousser_herbe() {
    // Augmentation de la probabilité de pousse d'herbe à chaque tour
    int pourcentage_pousse = 5 + tour; // Définir le pourcentage initial de pousse
    if (pourcentage_pousse > 9) {
        pourcentage_pousse = 9; // Limiter le pourcentage maximum à 9
    }

    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) { 
            if (grille[i][j] == 'S') {
                grille[i][j] = 'H'; // Transformation des sels minéraux en herbe 
            } else if (grille[i][j] == ' ' && (rand() % 100) < pourcentage_pousse) {
                grille[i][j] = 'H'; // Faire pousser de l'herbe aléatoirement
            } 
        }
    }
}


void Univers::afficher() {
    // Affiche la grille avec des repères le long des axes
    std::cout << "   "; 
    for (int j = 0; j < n; ++j) {
        std::cout << char('0' + j) << " | ";
    }
    std::cout << std::endl;

    // Ligne de séparation
    std::cout << "  ";
    for (int j = 0; j < n; ++j) { 
        std::cout << "____";
    }
    std::cout << std::endl;

    int moutons_vivants = 0; // Compter le nombre de moutons vivants pour l'affichage 

    for (int i = 0; i < m; ++i) {
        std::cout << i << " |";
        for (int j = 0; j < n; ++j) {
            bool animal_present = false;
            for (const auto& mouton : moutons) {
                if (mouton->get_x() == i && mouton->get_y() == j && mouton->est_vivant()) { 
                    std::cout << CYAN << " M " << RESET << "|";
                    animal_present = true;
                    moutons_vivants++;
                    break;
                }
            }
            if (!animal_present) {
                for (const auto& loup : loups) {
                    if (loup->get_x() == i && loup->get_y() == j) { 
                        std::cout << RED << " L " << RESET << "|";
                        animal_present = true;
                        break;
                    } 
                }
            }
            if (!animal_present) {
                if (grille[i][j] == 'H') {
                    std::cout << GREEN << " H " << RESET << "|";
                } else if (grille[i][j] == 'S' ) { 
                    std::cout << YELLOW << " S" << RESET << "|";
                } else {
                    std::cout << "   |";
                }
            }
        }
        std::cout << std::endl;
 
        // Ligne de séparation
        std::cout << "  ";
        for (int j = 0; j < n; ++j) {
            std::cout << "____";
        }
        std::cout << std::endl; 
    }
    std::cout << std::endl; 


    std::cout << "Tour: " << tour << std::endl; 
    std::cout << "Nombre total de moutons vivants : " << moutons_vivants << std::endl;
    std::cout << "Nombre total de loups : " << loups.size() << std::endl;

} 


void Univers::tour_suivant() {
    tour++;
    deplacer_animaux(); 
    gerer_alimentation();
    gerer_reproduction();
 
    for (auto& mouton : moutons) {
        mouton->vieillir();
    }
    for (auto& loup : loups) {
        loup->vieillir();
    } 

    nettoyer_animaux_morts();

    afficher();
    faire_pousser_herbe(); 

  
}

bool Univers::est_mort() {
    return moutons.empty() && loups.empty(); 
}

void Mouton::se_deplacer(int max_x, int max_y, std::vector<std::vector<char>>& grille) { 
    auto herbe_proche = trouver_herbe_proche(grille, max_x, max_y);
    int new_x = x;
    int new_y = y;

    if (herbe_proche.first != -1) {
        if (herbe_proche.first > x) new_x++; 
        else if (herbe_proche.first < x) new_x--;
        if (herbe_proche.second > y) new_y++;
        else if (herbe_proche.second < y) new_y--;
    } else {
        int direction = rand() % 4;
        switch (direction) {
        case 0: if (x > 0) new_x--; break;
        case 1: if (x < max_x - 1) new_x++; break;
        case 2: if (y > 0) new_y--; break;
        case 3: if (y < max_y - 1) new_y++; break; 
        }
    }
 
    if (grille[new_x][new_y] != 'L' && grille[new_x][new_y] != 'M') {
        x = new_x;
        y = new_y;
    }
}

void Mouton::manger(std::vector<std::vector<char>>& grille, std::vector<Animal*>& moutons, std::vector<Animal*>& loups) { 
    if (grille[x][y] == 'H') {
        grille[x][y] = ' ';
        faim = 0;
        std::cout << "Un mouton a mangé de l'herbe à la position : (" << x << ", " << y << ")" << std::endl; 
    }
}

bool Mouton::est_vivant() {
    return age < age_max && faim < 10; 
}

std::pair<int, int> Mouton::trouver_herbe_proche(std::vector<std::vector<char>>& grille, int max_x, int max_y) {
    int rayon = 3;
    for (int r = 1; r <= rayon; ++r) {
        for (int dx = -r; dx <= r; ++dx) {
            for (int dy = -r; dy <= r; ++dy) {
                int nx = x + dx;
                int ny = y + dy; 
                if (nx >= 0 && nx < max_x && ny >= 0 && ny < max_y && grille[nx][ny] == 'H') {
                    return {nx, ny};
                }
            }
        }
    } 
    return 0;
}

void Loup::se_deplacer(int max_x, int max_y, std::vector<std::vector<char>>& grille) {
    int direction = rand() % 4;
    int new_x = x;
    int new_y = y;

    switch (direction) {
    case 0: if (x > 0) new_x--; break;
    case 1: if (x < max_x - 1) new_x++; break;
    case 2: if (y > 0) new_y--; break;
    case 3: if (y < max_y - 1) new_y++; break;
    }

    if (grille[new_x][new_y] != 'L' && grille[new_x][new_y] != 'M') {
        x = new_x;
        y = new_y;
    }
}

void Loup::manger(std::vector<std::vector<char>>& grille, std::vector<Animal*>& moutons, std::vector<Animal*>& loups) {
    for (auto it = moutons.begin(); it != moutons.end(); ++it) {
        int mouton_x = (*it)->get_x();
        int mouton_y = (*it)->get_y();


        if (std::abs(mouton_x - x) <= 1 && std::abs(mouton_y - y) <= 1) {
   
            Mouton* mouton = dynamic_cast<Mouton*>(*it);
            if (mouton) {
                mouton->mange_par_loup = true;
                delete *it;
                moutons.erase(it);
                faim = 0;
                std::cout << "Un loup a mangé un mouton à la position : (" << x << ", " << y << ")" << std::endl;
                return; 
            }
        }  
    }
}


bool Loup::est_vivant() {
    return age < age_max && faim < 15;
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    Univers univers(10, 10, 5, 3);
    univers.initialiser();

    

    while (!univers.est_mort()) {
        univers.tour_suivant();
        std::cin.get(); // Appuyer sur Entrée pour passer au tour suivant
    }

    std::cout << "Tous les animaux sont morts. Fin de la simulation." << std::endl;

    return 0;
}