#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define TAILLE_TABLEAU 4000
#define MAX_OCCURRENCE_LENGTH 100
#define MAX_UNIQUE_OCCURRENCES 1000
#define HASH_TABLE_SIZE 1000  

typedef struct HashNode {
    char mot[MAX_OCCURRENCE_LENGTH]; 
    int count;
    struct HashNode *next;
} HashNode;

typedef struct {
    char mot[MAX_OCCURRENCE_LENGTH];
    int count;
} UniqueOccurrence;

HashNode* hashTable[HASH_TABLE_SIZE] = {0};

UniqueOccurrence uniqueOccurrences[MAX_UNIQUE_OCCURRENCES];
int totalUniqueOccurrences = 0;

int pointsLettre(char lettre) {
    switch (lettre) {
        case 'A': return 1;
        case 'Y': return 6;
        case 'K': return 14;
        case 'M': return 16;
        default: return 0;
    }
}

char lettreAleatoire() {
    char alphabet[4] = {'K', 'M', 'A', 'Y'};
    return alphabet[rand() % 4];
}

void remplirTableau(char tableau[TAILLE_TABLEAU]) {
    for (int i = 0; i < TAILLE_TABLEAU; ++i) {
        tableau[i] = lettreAleatoire();
    }
}

int hash(const char *str) {
    unsigned long hash = 5381;
    int c;
    while ((c = *str++))
        hash = ((hash << 5) + hash) + c;
    return hash % HASH_TABLE_SIZE;
}

void addUniqueOccurrence(const char *occurrence) {
    int index = hash(occurrence);
    HashNode *node = hashTable[index];
    
    while (node != NULL) {
        if (strcmp(node->mot, occurrence) == 0) {
            node->count++;
            return;
        }
        node = node->next;
    }
    
    HashNode *newNode = (HashNode *)malloc(sizeof(HashNode));
    if (newNode == NULL) {
        fprintf(stderr, "Erreur: Échec de l'allocation mémoire.\n");
        exit(EXIT_FAILURE);
    }
    strcpy(newNode->mot, occurrence);
    newNode->count = 1;
    newNode->next = hashTable[index];
    hashTable[index] = newNode;
    totalUniqueOccurrences++;
}

// Fonction pour rechercher le motif KA*Y+AM+ dans le tableau
void rechercherMotif1(char tableau[]) {
    int nbO = 1; 
    for (int i = 0; i < TAILLE_TABLEAU; ++i) {
        int points = 0;
        char occurrence[MAX_OCCURRENCE_LENGTH] = {0}; // stockage 
        int occLen = 0;
        
        if (tableau[i] == 'K') {
            int startPos = i; 
            occurrence[occLen++] = 'K';
            points += pointsLettre('K');
            i++; 
            
            while (i < TAILLE_TABLEAU && tableau[i] == 'A') {
                occurrence[occLen++] = 'A';
                points += pointsLettre('A');
                i++;
            }
            
            if (i < TAILLE_TABLEAU && tableau[i] == 'Y') {
                do {
                    occurrence[occLen++] = 'Y';
                    points += pointsLettre('Y');
                    i++;
                } while (i < TAILLE_TABLEAU && tableau[i] == 'Y');
                
                if (i < TAILLE_TABLEAU && tableau[i] == 'A') {
                    occurrence[occLen++] = 'A';
                    points += pointsLettre('A');
                    i++;
                    
                    if (i < TAILLE_TABLEAU && tableau[i] == 'M') {
                        do {
                            occurrence[occLen++] = 'M';
                            points += pointsLettre('M');
                            i++;
                        } while (i < TAILLE_TABLEAU && tableau[i] == 'M');

                        occurrence[occLen] = '\0';
                        addUniqueOccurrence(occurrence);
                        printf("%d [%d, %s, %d]\n", nbO++, startPos, occurrence, points);
                    }
                }
            }
        }
    }
}

//motif 2  K+AY+A?Y*M
void rechercherMotif2(char tableau[]) {
    int nbO = 1; 
    for (int i = 0; i < TAILLE_TABLEAU; ++i) {
        int points = 0;
        char occurrence[MAX_OCCURRENCE_LENGTH] = {0}; 
        int occLen = 0; 

       
        if (tableau[i] == 'K') {
            int startPos = i;
            do {
                occurrence[occLen++] = 'K';
                points += pointsLettre('K');
                i++;
            } while (i < TAILLE_TABLEAU && tableau[i] == 'K');
            
            
            if (i + 1 < TAILLE_TABLEAU && tableau[i] == 'A' && tableau[i + 1] == 'Y') {
                occurrence[occLen++] = 'A';
                points += pointsLettre('A');
                i++;

                occurrence[occLen++] = 'Y';
                points += pointsLettre('Y');
                i++;
                
               
                if (i < TAILLE_TABLEAU && tableau[i] == 'A') {
                    occurrence[occLen++] = 'A';
                    points += pointsLettre('A');
                    i++;
                }

                
                while (i < TAILLE_TABLEAU && tableau[i] == 'Y') {
                    occurrence[occLen++] = 'Y';
                    points += pointsLettre('Y');
                    i++;
                }

                
                if (i < TAILLE_TABLEAU && tableau[i] == 'M') {
                    occurrence[occLen++] = 'M';
                    points += pointsLettre('M');
                    i++;

                    occurrence[occLen] = '\0';
                    addUniqueOccurrence(occurrence);
                    printf("%d [%d, %s, %d]\n", nbO++, startPos, occurrence, points);
                }
            }
        }
    }
}

int collectOccurrences(UniqueOccurrence *allOccurrences) {
    int index = 0;
    for (int i = 0; i < HASH_TABLE_SIZE; i++) {
        for (HashNode *node = hashTable[i]; node != NULL; node = node->next) {
            if (index >= MAX_UNIQUE_OCCURRENCES) {
                fprintf(stderr, "Erreur\n");
                return index;
            }
            strcpy(allOccurrences[index].mot, node->mot);
            allOccurrences[index].count = node->count;
            index++;
        }
    }
    return index;
}

int compareOccurrences(const void *a, const void *b) {
    UniqueOccurrence *occA = (UniqueOccurrence *)a;
    UniqueOccurrence *occB = (UniqueOccurrence *)b;
    return occA->count - occB->count;  
}

void uniqueOccurenceTrierParNombre() {
    UniqueOccurrence *allOccurrences = malloc(MAX_UNIQUE_OCCURRENCES * sizeof(UniqueOccurrence));
    int numOccurrences = collectOccurrences(allOccurrences); 

    qsort(allOccurrences, numOccurrences, sizeof(UniqueOccurrence), compareOccurrences);

    printf("Occurrences uniques triées par nombre d'apparitions (ordre croissant):\n");
    for (int i = 0; i < numOccurrences; i++) {
        printf("%s: %d\n", allOccurrences[i].mot, allOccurrences[i].count);
    }

    printf("Nombre total d'occurrences différentes: %d\n", numOccurrences);

    free(allOccurrences); 
}

void uniqueOccurencePasTrier() {
    int totalOccurrences = 0;
    int uniqueOccurrencesCount = 0; 
    for (int i = 0; i < HASH_TABLE_SIZE; ++i) {
        HashNode *current = hashTable[i];
        while (current != NULL) {
            printf("%s %d\n", current->mot, current->count);
            totalOccurrences += current->count;
            uniqueOccurrencesCount++;
            current = current->next;
        }
    }

    printf("Nombre total d'occurences differentes : %d\n", uniqueOccurrencesCount);
}

void freeHashTable() {
    for (int i = 0; i < HASH_TABLE_SIZE; ++i) {
        HashNode *node = hashTable[i];
        while (node != NULL) {
            HashNode *temp = node;
            node = node->next;
            free(temp);
        }
    }
}


int diffPoints[MAX_UNIQUE_OCCURRENCES] = {0};
int nbDiffPoints = 0;

int calculerPointsOccurrence(const char* occurrence) {
    int points = 0;
    for (int i = 0; occurrence[i] != '\0'; i++) {
        points += pointsLettre(occurrence[i]);
    }
    return points;
}

void collecterDiffPoints(int *diffPoints, int *nbDiffPoints) {
    *nbDiffPoints = 0;

    for (int i = 0; i < HASH_TABLE_SIZE; i++) {
        for (HashNode *node = hashTable[i]; node != NULL; node = node->next) {
            int points = calculerPointsOccurrence(node->mot);
            int present = 0;
            for (int j = 0; j < *nbDiffPoints; j++) {
                if (diffPoints[j] == points) {
                    present = 1;
                    break;
                }
            }
            if (!present) {
                diffPoints[(*nbDiffPoints)++] = points;
            }
        }
    }
}

// Fonction de tri par sélection
void triSelection(int *tab, int taille) {
    for (int i = 0; i < taille - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < taille; j++) {
            if (tab[j] < tab[minIndex]) {
                minIndex = j;
            }
        }
        if (minIndex != i) {
            int temp = tab[i];
            tab[i] = tab[minIndex];
            tab[minIndex] = temp;
        }
    }
}

// Fonction de tri à bulles
int* triBulles(int *tab, int taille) {
    for (int i = 0; i < taille - 1; i++) {
        for (int j = 0; j < taille - i - 1; j++) {
            if (tab[j] > tab[j + 1]) {
                int temp = tab[j];
                tab[j] = tab[j + 1];
                tab[j + 1] = temp;
            }
        }
    }
    return tab;
}

void trierDiffPoints(int *diffPoints, int nbDiffPoints) {
    // Tri à bulles
    printf("Différents nombres de points triés par tri à bulles :\n");
    triBulles(diffPoints, nbDiffPoints);
    for (int i = 0; i < nbDiffPoints; i++) {
        printf("%d ", diffPoints[i]);
    }
    printf("\n");

    // Tri par sélection
    printf("Différents nombres de points triés par tri par sélection :\n");
    triSelection(diffPoints, nbDiffPoints);
    for (int i = 0; i < nbDiffPoints; i++) {
        printf("%d ", diffPoints[i]);
    }
    printf("\n");
}



double calculerMoyenneToutesOccurrences() {
    if (totalUniqueOccurrences == 0) {
        printf("Aucune occurrence trouvée.\n");
        return 0.0;
    }

    int sommeTotalePoints = 0;
    int totalOccurrences = 0;

    for (int i = 0; i < HASH_TABLE_SIZE; i++) {
        HashNode *node = hashTable[i];
        while (node != NULL) {
            int pointsOccurrence = 0;

            for (int j = 0; node->mot[j] != '\0'; j++) {
                pointsOccurrence += pointsLettre(node->mot[j]);
            }

            sommeTotalePoints += pointsOccurrence * node->count;
            totalOccurrences += node->count;

            node = node->next;
        }
    }

    double moyenneToutesOccurrences = (double)sommeTotalePoints / totalOccurrences;
    printf("Moyenne de toutes les occurrences : %.2f\n", moyenneToutesOccurrences);
    return moyenneToutesOccurrences;
}

double calculerMoyenneOccurrencesUniques() {
    if (totalUniqueOccurrences == 0) {
        printf("Aucune occurrence unique trouvée.\n");
        return 0.0;
    }

    int sommeTotalePoints = 0;

    for (int i = 0; i < HASH_TABLE_SIZE; i++) {
        HashNode *node = hashTable[i];
        while (node != NULL) {
            int pointsOccurrence = 0;

            for (int j = 0; node->mot[j] != '\0'; j++) {
                pointsOccurrence += pointsLettre(node->mot[j]);
            }

            sommeTotalePoints += pointsOccurrence;

            node = node->next;
        }
    }

    double moyenneOccurrencesUniques = (double)sommeTotalePoints / totalUniqueOccurrences;
    printf("Moyenne des occurrences uniques : %.2f\n", moyenneOccurrencesUniques);
    return moyenneOccurrencesUniques;
}

int main() {
    printf("Alphabet : KMAY\n Motif 1  : KA*Y+AM+ \n Motif 2  : K+AY+A?Y*M\n");
    printf("ETAPE 2 :  \n");
    printf("Motif 1 : KA*Y+AM+ \n");
    printf("Occurences trouvées: (Numéro, Position, Occurence, Points )\n");
    printf("--------------------------------------------------------------\n");
    srand(time(NULL)); 
    char tableau[TAILLE_TABLEAU];
    remplirTableau(tableau);
    rechercherMotif1(tableau);
    printf("Etape 3 : \n");
    printf("Motif 2 : K+AY+A?Y*M\n");
    printf("Occurences trouvées: (Numéro, Position, Occurence, Points )\n");
    printf("--------------------------------------------------------------\n");
    rechercherMotif2(tableau);
    printf("Etape 5 : \n");    
    printf("--------------------------------------------------------------\n");
    printf("Occurrences uniques et leur nombre d'apparitions:\n");
    uniqueOccurencePasTrier();
    printf("Etape 6 : \n");
    printf("--------------------------------------------------------------\n");    
    uniqueOccurenceTrierParNombre();
    printf("Etape 7 :  \n");
    printf("---------------------------------------------------------------\n");
    calculerMoyenneToutesOccurrences();
    printf("Etape 8 : \n");
    printf("----------------------------------------------------------------\n");
    collecterDiffPoints(diffPoints, &nbDiffPoints);
    trierDiffPoints(diffPoints, nbDiffPoints);
    printf("Nombre de points différents trouvés : %d\n", nbDiffPoints);
    printf("Etape 9 :\n");
    printf("------------------------------------------------------------------\n");
    calculerMoyenneOccurrencesUniques();
    freeHashTable();
    return 0;
}
