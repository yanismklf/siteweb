#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define TAILLE_TABLEAU 100
#define MAX_OCCURRENCE_LENGTH 100

char tableau[TAILLE_TABLEAU] = "KAAYYAMM KYYAMM KAYAM KKKAYYM KKAYYYM ";

int pointsLettre(char lettre) {
    switch (lettre) {
        case 'A': return 1;
        case 'Y': return 6;
        case 'K': return 14;
        case 'M': return 16;
        default: return 0;
    }
}

void rechercherMotif1(char tableau[]) {
    printf("Recherche du Motif 1 (KA*Y+AM+):\n");
    int nbO = 1; 
    for (int i = 0; i < TAILLE_TABLEAU; ++i) {
        int points = 0;
        char occurrence[MAX_OCCURRENCE_LENGTH] = {0}; // stockage 
        int occLen = 0;
        
        if (tableau[i] == 'K') {
            int startPos = i; 
            occurrence[occLen++] = 'K';
            points += pointsLettre('K');
            i++; 
            
            while (i < TAILLE_TABLEAU && tableau[i] == 'A') {
                occurrence[occLen++] = 'A';
                points += pointsLettre('A');
                i++;
            }
            
            if (i < TAILLE_TABLEAU && tableau[i] == 'Y') {
                do {
                    occurrence[occLen++] = 'Y';
                    points += pointsLettre('Y');
                    i++;
                } while (i < TAILLE_TABLEAU && tableau[i] == 'Y');
                
                if (i < TAILLE_TABLEAU && tableau[i] == 'A') {
                    occurrence[occLen++] = 'A';
                    points += pointsLettre('A');
                    i++;
                    
                    if (i < TAILLE_TABLEAU && tableau[i] == 'M') {
                        do {
                            occurrence[occLen++] = 'M';
                            points += pointsLettre('M');
                            i++;
                        } while (i < TAILLE_TABLEAU && tableau[i] == 'M');

                        
                        occurrence[occLen] = '\0';
                        printf("%d [%d, %s, %d]\n", nbO++, startPos, occurrence, points);
                    }
                }
            }
        }
    }
}

void rechercherMotif2(char tableau[]) {
    printf("Recherche du motif 2 : (K+AY+A?Y*M):\n");
    int nbO = 1; 
    for (int i = 0; i < TAILLE_TABLEAU; ++i) {
        int points = 0;
        char occurrence[MAX_OCCURRENCE_LENGTH] = {0}; 
        int occLen = 0; 

       
        if (tableau[i] == 'K') {
            int startPos = i;
            do {
                occurrence[occLen++] = 'K';
                points += pointsLettre('K');
                i++;
            } while (i < TAILLE_TABLEAU && tableau[i] == 'K');
            
            
            if (i + 1 < TAILLE_TABLEAU && tableau[i] == 'A' && tableau[i + 1] == 'Y') {
                occurrence[occLen++] = 'A';
                points += pointsLettre('A');
                i++;

                occurrence[occLen++] = 'Y';
                points += pointsLettre('Y');
                i++;
                
               
                if (i < TAILLE_TABLEAU && tableau[i] == 'A') {
                    occurrence[occLen++] = 'A';
                    points += pointsLettre('A');
                    i++;
                }

                
                while (i < TAILLE_TABLEAU && tableau[i] == 'Y') {
                    occurrence[occLen++] = 'Y';
                    points += pointsLettre('Y');
                    i++;
                }

                
                if (i < TAILLE_TABLEAU && tableau[i] == 'M') {
                    occurrence[occLen++] = 'M';
                    points += pointsLettre('M');
                    i++;

                    occurrence[occLen] = '\0';
                    printf("%d [%d, %s, %d]\n", nbO++, startPos, occurrence, points);
                }
            }
        }
    }
}

int main() {
    printf("Tableau prédéfini pour la recherche :\n%s\n\n", tableau);

    rechercherMotif1(tableau);

    rechercherMotif2(tableau);

    return 0;
}

