import socket
import select

def valid_name(name):
    return ' ' not in name and 1 <= len(name) <= 25

def receive_message(client_socket):
    try:
        message = client_socket.recv(1024).decode('utf-8').strip()
        if message:
            return message
    except:
        return None

def send_message(client_socket, message):
    try:
        client_socket.send(message.encode('utf-8'))
    except:
        client_socket.close()
        if client_socket in sockets_list:
            sockets_list.remove(client_socket)
            if client_socket in clients:
                del clients[client_socket]

def handle_new_connection(client_socket):
    send_message(client_socket, "NAME\n")
    pseudo = receive_message(client_socket)
    if pseudo and valid_name(pseudo) and pseudo not in clients.values():
        clients[client_socket] = pseudo
        send_message(client_socket, f"HELO {pseudo}\n")
        return True
    send_message(client_socket, "NOPE 12\n" if not valid_name(pseudo) else "NOPE 13\n")
    return False

def handle_private_message(sender_socket, recipient_name, message):
    recipient_socket = next((s for s, p in clients.items() if p == recipient_name), None)
    if recipient_socket:
        send_message(recipient_socket, f"PRIV {clients[sender_socket]} {message}\n")
        send_message(sender_socket, f"PRIV {recipient_name} {message}\n")
    else:
        send_message(sender_socket, "NOPE 14\n")

def handle_group_message(sender_socket, group_name, message):
    if group_name in groups and sender_socket in groups[group_name]:
        for client in groups[group_name]:
            if client != sender_socket:
                send_message(client, f"MESS {group_name} {clients[sender_socket]} {message}\n")
    else:
        send_message(sender_socket, "NOPE 18\n")

def create_group(sender_socket, group_name, max_members):
    if group_name in groups:
        send_message(sender_socket, "NOPE 13\n")
        return
    try:
        max_members = int(max_members)
        if max_members < 1:
            raise ValueError
        groups[group_name] = {sender_socket}
        max_group_members[group_name] = max_members
        send_message(sender_socket, f"INTO {group_name} 1\n{clients[sender_socket]}\n")
    except ValueError:
        send_message(sender_socket, "NOPE 17\n")

def join_group(sender_socket, group_name):
    if group_name not in groups or len(groups[group_name]) >= max_group_members[group_name]:
        send_message(sender_socket, "NOPE 16\n")
        return
    groups[group_name].add(sender_socket)
    for client in groups[group_name]:
        send_message(client, f"INTO {group_name} {len(groups[group_name])}\n" + "\n".join(clients[c] for c in groups[group_name]) + "\n")

def list_connected_clients(sender_socket):
    send_message(sender_socket, f"LIST {len(clients)}\n" + "\n".join(clients.values()) + "\n")

def list_groups(sender_socket):
    send_message(sender_socket, f"GRPL {len(groups)}\n" + "\n".join(groups.keys()) + "\n")

def server_loop():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('127.0.0.1', 65432))
    server_socket.listen()
    sockets_list.append(server_socket)

    while True:
        read_sockets, _, exception_sockets = select.select(sockets_list, [], sockets_list)
        for notified_socket in read_sockets:
            if notified_socket == server_socket:
                client_socket, _ = server_socket.accept()
                sockets_list.append(client_socket)
            else:
                message = receive_message(notified_socket)
                if message:
                    command, *args = message.split()
                    if command == "NAME" and args:
                        if not handle_new_connection(notified_socket):
                            notified_socket.close()
                            sockets_list.remove(notified_socket)
                    elif command == "PRIV" and len(args) >= 2:
                        handle_private_message(notified_socket, args[0], ' '.join(args[1:]))
                    elif command == "MESS" and len(args) >= 2:
                        handle_group_message(notified_socket, args[0], ' '.join(args[1:]))
                    elif command == "CRGP" and len(args) == 2:
                        create_group(notified_socket, args[0], args[1])
                    elif command == "JOIN" and args:
                        join_group(notified_socket, args[0])
                    elif command == "LIST":
                        list_connected_clients(notified_socket)
                    elif command == "GRPL":
                        list_groups(notified_socket)
                else:
                    sockets_list.remove(notified_socket)
                    notified_socket.close()
                    clients.pop(notified_socket, None)

if __name__ == "__main__":
    clients = {}
    groups = {}
    max_group_members = {}
    sockets_list = []
    server_loop()
