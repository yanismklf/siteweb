import socket

def send_message(client_socket, message):
    try:
        client_socket.sendall(message.encode('utf-8'))
    except Exception as e:
        print("Failed to send message:", e)

def receive_message(client_socket):
    try:
        return client_socket.recv(1024).decode('utf-8').strip()
    except Exception as e:
        print("Failed to receive message:", e)
        return None

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('127.0.0.1', 65432))

    while True:
        message = input("Enter command: ")
        send_message(client_socket, message)
        if message.lower() == "exit":
            break
        response = receive_message(client_socket)
        if response:
            print("Received:", response)

    client_socket.close()

if __name__ == "__main__":
    main()
